const button = document.getElementsByClassName("btn")[0];
var contador = 1;
setInterval(pasarImagen, 3000);
function validardatos(event){
    event.preventDefault();
       if(document.getElementById("password").value == ""){
        document.getElementById("password").classList.add("is-invalid");
        document.getElementById("password").classList.remove("is-valid");
    } else{
        document.getElementById("password").classList.add("is-valid");
        document.getElementById("password").classList.remove("is-invalid");
    }

    if(document.getElementById("username").value.length > 15 || document.getElementById("username").value.length < 3 || document.getElementById("username").value == ""){
        document.getElementById("username").classList.add("is-invalid");
        document.getElementById("username").classList.remove("is-valid");
    } else{
        document.getElementById("username").classList.add("is-valid");
        document.getElementById("username").classList.remove("is-invalid");
    }
}

    

 