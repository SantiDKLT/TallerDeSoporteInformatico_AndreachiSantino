const express = require('express')
const mysql = require('mysql');
const bodyParser = require('body-parser')
const app = express()
const port = 3000

app.use(express.static('./dist/client'));
app.use(express.static('public'));
app.use(bodyParser.urlencoded());
app.use(bodyParser.json());


const connection = mysql.createConnection({
  host: 'localhost',
  user: 'alumno',
  password: 'alumnoipm',
  database: 'pagina'
});
connection.connect((error) => {
  if (error) {
    console.error('Error connecting to the database: ' + error.stack);
    return;
  }
  console.log('Connected to the database.');
});


app.listen(port, () => {
  console.log(`Servidor totalmente funcional en  http://localhost:${port}`);
});


app.get('/', (req, res) => {
  res.send('Hello World!')
})


app.get("/forms", (req, res) => {
  res.send(`<html lang="en">
  <head class="responsive">
      <head>
          <title>Formulario</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
          <link rel="stylesheet" href="style.css">
          <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
          <script src="Scripts.js"></script>
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
          integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8"
          crossorigin="anonymous"></script>
        </head>
  </head>
  <div class="responsive-page-template-content">
    <header>
      <nav class="navbar navbar-expand-lg bg-body-tertiary" id="NavBarr">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">INT</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <a class="nav-link active" aria-current="page" href="Formulario.html">Registrarse</a>
                </li>
              </li>
              <li class="nav-item dropdown">
              </li>
            </ul>
            <form class="d-flex" role="search">
              <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Search">
              <button class="btn btn-outline-success" type="submit">Ir</button>
            </form>
          </div>
        </div>
      </nav>
      <br>
    </header>
  </div>
  <body>
  <div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action = "/insert" id="myform" style="color: rgb(0, 0, 0);">
              <div class="form-group">
                <label>Nombre:</label>
                <input type="text" id="nombreUsuario" name="nombre" class="campo" placeholder="Ingrese su nombre">
                <div id="mensaje1" class="errores"></div>
              </div>
  
                <br><br>
  
              <div class="form-group">  
                <label>Mail</label>
                <input type="text" id="mailUsuario" name="apellido" class="campo" placeholder="Ingrese su Mail">
                <div id="mensaje2" class="errores"></div>
              </div>
  
                <br><br>
  
                <div class="form-group">
                <label>Mensaje:</label>
                <input type="text" id="MensajeaPoner" name="correo" class="campo" placeholder="Ingrese su Mensaje">
                <div id="mensaje3" class="errores"></div>
              </div>
  
                <br><br>
  
                <button type="submit" id="enviarForms" class="boton">Enviar</button>
            </form>
          </div>
        </div>
      </div>
  </body>
  </html>`);
});

app.post('/insert', (req, res) => {
  console.log(req);
  const { Nombre, Mail, Mensaje } = req.body;

  const query = 'INSERT INTO Clientes (nombre, correo, mensaje) VALUES (?, ?, ?);';
  connection.query(query, [Nombre, Mail, Mensaje], (error) => {
    if (error) {
      console.error('error al insertar: ', error);
      res.send('error al insertar');
      return;
    }
    res.send('fila insertada correctamente');
  });
});

app.get('/formu', function(req, res){
  res.sendFile(__dirname + '/Formulario.html');
});
app.get('/random', function(req, res){
  res.sendFile(__dirname + '/PaginaRandom.html');
});
app.get('/carrusel', function(req, res){
  res.sendFile(__dirname + '/carrusel.html');
});


app.use(express.static('PaginaWebFormularioNodeQuieroAprobarEstoPlis'));
app.use(express.static('PaginaWeb2Carrusel'));
app.use(express.static('public'))


//cuando no hay pagina...... creo......
app.use((req, res) =>{

  res.status(404).send('Yo soy la unica cosa que te detiene de romper el programa. Agradeceme...... Por favor.....')

})




