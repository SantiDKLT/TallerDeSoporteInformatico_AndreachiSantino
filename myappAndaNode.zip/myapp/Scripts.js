  $(document).ready(function() {
    $('#myform').submit(function(event) {

      event.preventDefault(); // no se puede enviar form. como està

  
      var nombreUsuario = $('#nombreUsuario').val().trim();
      var mailUsuario = $('#mailUsuario').val().trim();
      var MensajeaPoner = $('#MensajeaPoner').val().trim();
  
      // oculta mensajes de error
      $('.errores').hide();
  
      if (nombreUsuario === '') {
        alert('#mensaje1', 'Ingrese nombre');
      } else if (mailUsuario === '') {
        alert('#mensaje2', 'Ingrese un mail');
      } else if (!validarEmail(mailUsuario)) {
        alert('#mensaje2', 'Mail invalido');
      } else if (MensajeaPoner === '') {
        alert('#mensaje3', 'Ingrese una Mensaje');
      } else {
        window.location.href = '/PaginaRandom.html';
        // Redirecciona a la primera página
        
      }
    });
  
    function alert(selector, mensaje) {
      $(selector).text(mensaje).show();
    }
  
    function validarEmail(email) { //verifica mail
      var regex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
      return regex.test(email);
    }
  });
  