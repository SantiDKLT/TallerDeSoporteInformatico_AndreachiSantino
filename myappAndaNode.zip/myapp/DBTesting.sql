create database DBTesting;
use DBTesting;


create table Clientes(
	nombre varchar(50) not null,
    correo varchar(200) not null,
    mensaje varchar(300) not null
);

select * from Clientes;